"""
RAG (Retrieval Augmented Generation) package for security finding analysis.
"""
__version__ = "1.0.0"
