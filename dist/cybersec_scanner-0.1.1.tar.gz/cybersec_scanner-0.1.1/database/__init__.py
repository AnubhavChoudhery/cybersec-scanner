"""
Database normalization package for security findings.
"""
__version__ = "1.0.0"
